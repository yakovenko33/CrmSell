<?php

namespace CrmSell\Providers\Application\GetList\Request;

class GetList extends \CrmSell\Common\Application\Service\Request\GetList
{
    public function __construct(array $request)
    {
        parent::__construct($request);
    }
}
