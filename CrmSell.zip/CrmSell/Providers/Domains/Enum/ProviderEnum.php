<?php

namespace CrmSell\Providers\Domains\Enum;

enum ProviderEnum: string
{
    case COMFY = 'comfy';
}
