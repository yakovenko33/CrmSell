<?php

namespace CrmSell\Status\Domains\Enum;

enum DefectEnum: string
{
    case IN_ORDER = 'in_order';
}
