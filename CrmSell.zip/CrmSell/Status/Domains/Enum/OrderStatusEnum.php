<?php

namespace CrmSell\Status\Domains\Enum;


enum OrderStatusEnum: string
{
    case NEW = 'new';
}
