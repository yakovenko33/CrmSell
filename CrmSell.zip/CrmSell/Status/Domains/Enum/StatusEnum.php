<?php

namespace CrmSell\Status\Domains\Enum;

enum StatusEnum: string
{
    case DEFECT = 'defect';
    case STATUS = 'status';
}
