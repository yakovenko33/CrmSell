<?php

namespace CrmSell\Goods\Application\CRUD\GetList\Request;


class GetList extends \CrmSell\Common\Application\Service\Request\GetList
{
    public function __construct(array $request)
    {
        parent::__construct($request);
    }
}
